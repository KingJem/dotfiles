def Call():
    var_1 = 5

    var_all = 1  # Break here

if __name__ == '__main__':
    Call()
    print('TEST SUCEEDED!')