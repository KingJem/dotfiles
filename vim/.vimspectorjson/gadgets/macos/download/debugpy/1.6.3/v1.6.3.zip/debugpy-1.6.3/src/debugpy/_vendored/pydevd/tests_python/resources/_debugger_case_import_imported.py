print('text 1')
print('text 2')
